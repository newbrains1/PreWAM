PreWAM simulation rollouts

These are the exact six MP4 files used in the project page gallery.
Original saved playback timing is preserved; no speed-up is applied.
Videos have different source resolutions and frame rates; see video_info.json.
No audio tracks are included.
